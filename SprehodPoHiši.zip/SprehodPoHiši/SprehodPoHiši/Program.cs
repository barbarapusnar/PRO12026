﻿namespace SprehodPoHiši
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
